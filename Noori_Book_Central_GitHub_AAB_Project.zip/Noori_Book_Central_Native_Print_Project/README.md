Noori Book Central — Native Android Print/PDF Project

یہ Android Studio project HTML کے Print/PDF بٹن کو Native Android PrintManager سے جوڑتا ہے۔
Print بٹن دبانے پر Android کا system Print UI کھلے گا، جہاں Save as PDF یا printer منتخب کیا جا سکتا ہے۔

Build:
Android Studio میں project کھولیں → Gradle Sync → Build → Generate Signed Bundle / APK → Android App Bundle۔

اہم:
یہ source project ہے، signed AAB نہیں۔ Play Store کے لیے release keystore کے ساتھ signed AAB بنائیں۔
