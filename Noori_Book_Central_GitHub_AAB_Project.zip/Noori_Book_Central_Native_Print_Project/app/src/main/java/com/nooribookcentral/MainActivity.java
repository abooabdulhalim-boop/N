package com.nooribookcentral;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());

        // Native bridge: HTML button can call AndroidPrint.print().
        webView.addJavascriptInterface(new AndroidPrint(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidPrint {
        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (pm == null) {
                    Toast.makeText(MainActivity.this, "Print service دستیاب نہیں", Toast.LENGTH_LONG).show();
                    return;
                }
                PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build();

                pm.print(
                        "Noori Book Central",
                        webView.createPrintDocumentAdapter("Noori Book Central"),
                        attrs
                );
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
